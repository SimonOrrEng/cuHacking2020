import React, { Fragment } from "react";

import AuthState from "./context/auth/AuthState";
import './App.css';
import Register from './components/auth/Register';

const App = () => {
  return ( 
    <AuthState>
      <Router>
        <Fragment>
          <Navbar />
          <div className='container'>
            <Switch>
              <Route exact path='/' component ={Home} />
              <Route exact path='/about' component={About}/>
              <Route exact path='/register' component={Register}/>
            </Switch>
          </div>
        </Fragment>
      </Router>
    </AuthState>
  );
};